$execute if data block ~ ~ ~ Items[{id:"$(id)"}] run function x1_quickstack:logic/transfer_item_macro {"id":"$(id)","source_slot":"3","item_slot":"hotbar.3"}
